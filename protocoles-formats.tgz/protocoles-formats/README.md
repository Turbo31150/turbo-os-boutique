# Pack Protocoles & formats ouverts

Corpus de connaissance Turbo OS : 248 extraits (création originale).

Domaines : protocoles, formats-ouverts

26 extrait(s) de source tierce ont été EXCLUS par origine (détail : {'url_tierce_dans_texte': 21, 'marqueur_web_scrape': 5}) — voir le garde-fou v2 dans boutique_build_packs.py.

Contenu : corpus.jsonl (un extrait par ligne : texte + métadonnées), manifest.json.
